<?php
ob_start();
session_start();
require_once 'dbconnect.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
// select logged in users detail
$res = $conn->query("SELECT * FROM users WHERE id=" . $_SESSION['user']);
$userRow = mysqli_fetch_array($res, MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Hello,<?php echo $userRow['email']; ?></title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"/>
    <link rel="stylesheet" href="assets/css/index.css" type="text/css"/>
</head>
<body>
<!-- Navigation Bar-->
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                    aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">MishraEye</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
                <li class="active"><a href="#">Home</a></li>
                <!-- <li><a href="#">Tab1</a></li>
                <li><a href="#">Tab2</a></li> -->
            </ul>
            <ul class="nav navbar-nav navbar-right">

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">
                        <span
                            class="glyphicon glyphicon-user"></span>&nbsp;Logged
                        in: <?php echo $userRow['email']; ?>
                        &nbsp;<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Logout</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <!-- Jumbotron-->
    <div class="jumbotron">
        <h1>Hello, <?php echo $userRow['username']; ?></h1>
        <p>At MishraEye our mission is to help people see more, be more and live life to its fullest. Our groundbreaking products correct, protect and frame the beauty of our most precious sensory organ – our eyes. By combining our expertise in lens technology and eyewear manufacturing, a portfolio of brands that consumers love and global distribution capabilities, we enable people everywhere to learn, to work, to express themselves and to fulfill their potential. </p>
        <p><a class="btn btn-primary btn-lg right" href="#" onclick="myFunction()" role="button">Learn more</a></p>
    </div>        
    <div class="row" style="display:none" id="more">
        <div class="col-lg-12">
            <h1>See more— Be More<a style="margin-left:61%;" class="btn btn-primary btn-lg float" href="#" onclick="letsgo()" role="button">Let's Go!</a></h1>
			<p>MishraEye  Group is a leader in the design, manufacture and distribution of fashion, luxury, sports and performance eyewear.</p>
			
			<p>Among its core strengths, a strong and well-balanced brand portfolio includes  proprietary brands such as Ray-Ban, one of the world's best-known eyewear brands, Oakley, one of the leading product design and sport performance brands globally, Vogue Eyewear, Persol, Oliver Peoples, Alain Mikli and Arnette, and prestigious licensed brands such as Giorgio Armani, Burberry, Bulgari, Chanel, Dolce&Gabbana, DKNY, Ferrari, Michael Kors, Miu Miu, Paul Smith, Prada, Ralph Lauren, Starck Eyes, Tiffany & Co., Tory Burch, Valentino and Versace.</p>
			
			<p><a href="#">MishraEye's international </a>expansion has developed its geographic footprint worldwide. The Group’s global wholesale distribution network covers more than <strong>150 countries </strong> and is complemented by an extensive retail network of approximately 9,000 stores, with LensCrafters and Pearle Vision in North America, OPSM and Laubman & Pank in Australia and New Zealand, GMO and Óticas Carol in Latin America, Salmoiraghi&Viganò in Italy and Sunglass Hut worldwide.</p>
			
			<p>One of the Group’s competitive advantages is the vertically integrated business model built over the years, covering the entire value chain: design, product development, manufacturing, logistics and distribution.</p>
			<p>Product design, development and manufacturing take place in MishraEye’s six manufacturing  facilities located in Italy, three facilities in China, one in Brazil and one facility in the United States devoted to sports and performance eyewear. MishraEye also has a small plant in India serving the local market.
				MishraEye also has produced sun and ophthalmic lenses for more than<em> 20 years</em>. 
				The Company has increased its manufacturing capacity with the recent addition of three new laboratories in Europe, North America and Asia-Pacific which are completely integrated with its logistics hubs.</p>                      
        </div>
	</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script>function myFunction() {
    var x = document.getElementById("more");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
</script>
<script>
function letsgo() {
    window.location.href="question.php";
}
</script>
</body>
</html>
